package hotel;

public interface RoomFees {

    public abstract double CustomerRoomFees(Room room);
}
